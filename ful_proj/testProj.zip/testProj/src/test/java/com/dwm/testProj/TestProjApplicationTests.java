package com.dwm.testProj;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestProjApplicationTests {

	@Test
	void contextLoads() {
	}

}
